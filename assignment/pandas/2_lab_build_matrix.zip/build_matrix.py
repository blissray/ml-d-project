import numpy as np
import pandas as pd


def get_rating_matrix(filename, dtype=np.float32):
    pass


def get_frequent_matrix(filename, dtype=np.float32):
    pass
